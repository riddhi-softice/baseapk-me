<?php
$links = [
    "https://videoapps.club/auto_redirect/post-1",
    "https://videoapps.club/auto_redirect/post-2",
    "https://videoapps.club/auto_redirect/post-3",
    "https://videoapps.club/auto_redirect/post-4"
];

$randomLink = $links[array_rand($links)];

// Log the selected link with timestamp
$logLine = date('Y-m-d H:i:s') . " - Redirected to: " . $randomLink . PHP_EOL;
file_put_contents("logs.txt", $logLine, FILE_APPEND);

// Redirect
header("Location: $randomLink");
exit;
?>
