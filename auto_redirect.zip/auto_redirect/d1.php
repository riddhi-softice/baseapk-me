<?php
/*$links = [
  "https://videoapps.club/auto_redirect/post-1",
  "https://videoapps.club/auto_redirect/post-2",
  "https://videoapps.club/auto_redirect/post-3",
  "https://videoapps.club/auto_redirect/post-4"
];*/

$links = [
        "https://100-play-online.baseapk.me",
        "https://99-playquiz.baseapk.me/life.html",
        "https://107-ffquize.baseapk.me/life.html",
        "https://baseapk.me"
    ];

$randomLink = $links[array_rand($links)];
header("Location: $randomLink");
exit;
